<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

    <div class="profile">
        <h1>Профиль</h1>
        <div class="info-profile">
            <h3>Ваши заказы</h3>

            <?php if($orders->count() > 0): ?>
                <div class="profile_order">
                    <table class="table table-bordered">
                        <tr>
                            <th>№</th>
                            <th>Дата и время</th>
                            <th>Покупатель</th>
                            <th>Номер телефона</th>
                            <th>Адрес</th>
                            <th>Количество товаров</th>
                            <th>Общая сумма</th>
                            <th>Комментарий</th>

                        </tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->email); ?></td>
                                <td><?php echo e($order->address); ?></td>
                                <td><?php echo e($order->count); ?></td>
                                <td><?php echo e($order->total_sum); ?></td>
                                <td><?php echo e($order->comment); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>


                </div>
            <?php else: ?>
                <p>Заказов пока нет</p>
            <?php endif; ?>


        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/profile/order.blade.php ENDPATH**/ ?>