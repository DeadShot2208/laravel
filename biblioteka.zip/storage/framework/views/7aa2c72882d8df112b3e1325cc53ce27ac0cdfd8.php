<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<main class="col_main">
    <container>

        <!-- Slider main container -->
        <div class="swiper">

            <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="img/slide_1.png" alt="">
                    <h2><b>Книжник открыл свой сайт заходи и заказывай.</b></h2>
                </div>
                <div class="swiper-slide"><img src="img/slide_2.png" alt=""></div>
                <div class="swiper-slide"><img src="img/slide_1.png" alt=""></div>
            </div>

            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>

        </div>
        <div class="zagolovok">
            <h1>Популярные категории</h1>
        </div>

        <div class="kategory">
            <?php $__currentLoopData = $categoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box_kategory">
                <?php if($category->image !== ''): ?><img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($category->image)); ?>" alt=""><?php endif; ?>
                <h3><?php echo e($category['title']); ?></h3>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <div class="zagolovok">
            <h1>Хиты продаж</h1>
        </div>

        <div class="product">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box_product">
                <a href="<?php echo e(route('getPost',[$product->category['slug'], $product->slug])); ?>"><?php if($product->image !== ''): ?><img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($product->image)); ?>" alt=""><?php endif; ?></a>
                <div class="info_product">
                    <h3><?php echo e($product['title']); ?></h3>
                    <div class="opisanie">
                        <p><?php echo e($product['subcontent']); ?></p>
                    </div>
                    <div class="inn">
                        <h4>Автор:<?php echo e($product['author']); ?></h4>
                        <h4>Жанр:<?php echo e($product->category->title); ?></h4>
                        <h4>Цена:<?php echo e($product['price']); ?>руб</h4>
                    </div>
                    <div class="known">
                        <form action="<?php echo e(route('basketAdd', $product)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("POST"); ?>
                            <button type="submit" class="button button5">В корзину</button>
                        </form>

                        <form action="<?php echo e(route('favouritesStore', $product)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("POST"); ?>
                            <button type="submit" style="border: 0"><img src="<?php echo e(asset('img/izbr.png')); ?>" alt=""></button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </container>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/home.blade.php ENDPATH**/ ?>