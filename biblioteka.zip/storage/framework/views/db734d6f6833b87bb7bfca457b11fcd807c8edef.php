<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body class="admin">
<header class="admin-header">
    <container>
        <h3>NAME:<?php echo e(Auth::user()->name); ?></h3>
        <div class="list-menu">
            <a href="<?php echo e(route('admin')); ?>">Главная</a>
            <a href="<?php echo e(route('orders')); ?>">Заказы</a>
            <a href="<?php echo e(route('user')); ?>">Пользователи</a>
            <a href="<?php echo e(route('categories')); ?>">Категории</a>
            <a href="<?php echo e(route('products')); ?>">Товары</a>
            <a href="<?php echo e(route('home')); ?>">Выход</a>
        </div>
    </container>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer>
    <container>

    </container>
</footer>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/layouts/admin-layout.blade.php ENDPATH**/ ?>