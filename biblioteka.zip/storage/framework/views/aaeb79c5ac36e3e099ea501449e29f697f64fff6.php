

<?php $__env->startSection('title', 'category'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main-admin">
        <container>
            <div class="wrapp__admin__panel">
                <div class="list__table">
                    <div class="table">
                        <div class="title__table">
                            <p>Пользователи</p>
                            <a href="<?php echo e(route('add_category')); ?>" class="create">Добавить</a>
                        </div>
                        <table class="table__db">
                            <thead>
                            <th>ID</th>
                            <th>Заголовок</th>
                            <th>Слаг</th>
                            <th>img</th>
                            <th>Дата создания</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->slug); ?></td>
                                <td><?php if($item->image !== ''): ?><img  src="<?php echo e(\Illuminate\Support\Facades\Storage::url($item->image)); ?>" alt=""><?php endif; ?></td>

                                <td><?php echo e($item->created_at); ?></td>
                                <td >
                                    <a href="<?php echo e(route('edit_category', $item->id)); ?>" class="edit">Редактировать</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('category.destroy', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="destroy">Удалить</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <?php echo e($category->links('vendor.pagination.bootstrap-5')); ?>

            </div>

        </container>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/category.blade.php ENDPATH**/ ?>