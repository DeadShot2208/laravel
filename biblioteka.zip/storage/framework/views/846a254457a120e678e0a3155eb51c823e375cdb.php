

<?php $__env->startSection('title', 'add_product'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main-admin">
        <container>
            <div class="wrapp__admin__panel">
                <p class="title">Создание категории</p>
                <form action="<?php echo e(route('product.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input__group">
                        <label for="title">Заголовок</label>
                        <input type="text" name="title">

                    </div>
                    <div class="input__group">
                        <label for="category_id">Категория</label>
                        <select name="category_id">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="input__group">
                        <label for="subcontent">краткое описание</label>
                        <input type="text" name="subcontent">
                    </div>
                    <div class="input__group">
                        <label for="content">описание</label>
                        <input type="text" name="content">
                    </div>
                    <div class="input__group">
                        <label for="author">Автор</label>
                        <input type="text" name="author">
                    </div>
                    <div class="input__group">
                        <label for="price">Стоимость</label>
                        <input type="text" name="price">
                    </div>
                    <div class="input__group">
                        <label for="slug">Слаг</label>
                        <input type="text" name="slug">
                    </div>

                    <<div class="input__group">
                        <label for="image">Загрузить фото</label>
                        <input type="file" id="image" name="image">
                    </div>

                    <div class="input__group">
                        <input type="submit" class="btn__add" value="Добавить">
                    </div>
                </form>
            </div>
            </div>
        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/add/add_product.blade.php ENDPATH**/ ?>