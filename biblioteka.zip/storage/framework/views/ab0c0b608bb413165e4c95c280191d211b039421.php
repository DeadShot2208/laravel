<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main_katalog">
        <container>
            <div class="zagolovok-1">
                <h1>Книжные хиты</h1>
            </div>

            <div class="swiper-col">
                <section class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide" style="background-image:url(<?php echo e(asset('img/product_hit.jpg')); ?>)">
                            <div class="swiper-content">
                                <p class="swiper-title" data-swiper-parallax="-30%" data-swiper-parallax-scale=".7">Заголовок</p>
                                <span class="swiper-caption" data-swiper-parallax="-20%">Описание слайда</span>
                            </div>
                        </div>

                        <div class="swiper-slide" style="background-image:url(<?php echo e(asset('img/product_hit2.jpg')); ?>)">
                            <div class="swiper-content">
                                <p class="swiper-title" data-swiper-parallax="-30%" data-swiper-parallax-scale=".7">Заголовок</p>
                                <span class="swiper-caption" data-swiper-parallax="-20%">Описание слайда</span>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-prev swiper-button-white"></div>
                    <div class="swiper-button-next swiper-button-white"></div>
                </section>
            </div>

            <div class="zagolovok-2">
                <h1>Сортировать по жанрам</h1>
            </div>

            <div class="sortirovka">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('getByCategory',$category->slug)); ?>"><?php echo e($category->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <div class="zagolovok-2">
                <h1>Книги</h1>
            </div>

            <div class="product-1">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box_product">
                        <a href="<?php echo e(route('getPost',[$product->category['slug'], $product->slug])); ?>"><?php if($product->image !== ''): ?><img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($product->image)); ?>" alt=""><?php endif; ?></a>
                        <div class="info_product">
                            <h3><?php echo e($product['title']); ?></h3>
                            <div class="opisanie">
                                <p><?php echo e($product['subcontent']); ?></p>
                            </div>
                            <div class="inn">
                                <h4>Автор:<?php echo e($product['author']); ?></h4>
                                <h4>Жанр:<?php echo e($product->category->title); ?></h4>
                                <h4>Цена:<?php echo e($product['price']); ?>руб</h4>
                            </div>
                            <div class="known">
                                <form action="<?php echo e(route('basketAdd', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("POST"); ?>
                                    <button type="submit" class="button button5">В корзину</button>
                                </form>

                                <form action="<?php echo e(route('favouritesStore', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("POST"); ?>
                                    <button type="submit" style="border: 0"><img src="<?php echo e(asset('img/izbr.png')); ?>" alt=""></button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($products->links('vendor.pagination.bootstrap-5')); ?>

        </container>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/katalog.blade.php ENDPATH**/ ?>