


<?php $__env->startSection('title', 'user'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main-admin">
        <container>
            <h1 style="display: flex; align-items: center; justify-content: center; color: white;" >Приветствую <?php echo e(Auth::user()->name); ?></h1>

        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/index.blade.php ENDPATH**/ ?>