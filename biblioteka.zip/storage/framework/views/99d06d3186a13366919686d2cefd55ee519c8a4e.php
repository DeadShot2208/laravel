

<?php $__env->startSection('title', $product->title); ?>

<?php $__env->startSection('content'); ?>

    <main class="col_main">
        <container>
            <div class="cards_products">
                <div class="name_product">
                    <h1><?php echo $product->title; ?> </h1>
                </div>
                <div class="title_product">
                    <div class="image_product">
                        <?php if($product->image !== ''): ?><img style="width: 200px; height: 300px; margin: 30px"  src="<?php echo e(\Illuminate\Support\Facades\Storage::url($product->image)); ?>" alt=""><?php endif; ?>
                    </div>
                    <div class="contact_product">
                <h5>Автор:<?php echo $product->author; ?></h5>
                        <h5>Стоимость:<?php echo $product->price; ?></h5>
                        <p>описание:<?php echo $product->subcontent; ?></p>
                        <button class="button button5">В корзину</button>
                    </div>
                </div>
                <div class="content_product">
    <p style="line-height: 2.5; width: 90%"><?php echo $product->content; ?></p>
                </div>
                <div class="category_card">
                <p>Категория:<?php echo $product->category->title; ?></p>
                </div>
            </div>
        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/product.blade.php ENDPATH**/ ?>