

<?php $__env->startSection('title', 'category'); ?>

<?php $__env->startSection('content'); ?>

    <div class="wrapp__admin__panel">
        <p class="title">Редактирование категории</p>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('category.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="input__group">
                    <label for="title">Заголовок</label>
                    <input type="text" name="title" value="<?php echo e($item->title); ?>" >
                </div>
                <div class="input__group">
                    <label for="slug">Слаг</label>
                    <input type="text" name="slug" value="<?php echo e($item->slug); ?>">
                </div>

                <<div class="input__group">
                    <label for="image">Загрузить фото</label>
                    <input type="file" id="image" name="image">
                </div>

                <div class="input__group">
                    <input type="submit" class="btn__add" value="Добавить">
                </div>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/edit/edit_category.blade.php ENDPATH**/ ?>