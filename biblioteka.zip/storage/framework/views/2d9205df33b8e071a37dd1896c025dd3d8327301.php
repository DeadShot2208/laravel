


<?php $__env->startSection('title', 'user'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main-admin">
        <container>
            <div class="wrapp__admin__panel">
                <div class="list__table">
                    <div class="table">
                        <div class="title__table">
                            <p>Заказы</p>
                        </div>
                        <table class="table__db">
                            <thead>
                            <th>ID</th>
                            <th>Дата создания</th>
                            <th>Статус</th>
                            <th>Покупатель</th>
                            <th>email</th>
                            <th>Номер телефона</th>
                            <th>Пользователь</th>

                            </thead>
                            <tbody>
                                <tr>
                                    <td>0000</td>
                                    <td>000000</td>
                                    <td>0000000</td>
                                    <td style="width: 10%">0000</td>
                                    <td style="width: 25%">0000000</td>
                                    <td>00000000</td>
                                    <td>000000000</td>
                                    <td style="width: 15%">
                                        <a href="" class="edit">Редактировать</a>
                                    </td>
                                    <td>
                                        <form action="" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="destroy">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/orders.blade.php ENDPATH**/ ?>