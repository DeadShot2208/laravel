<?php $__env->startSection('title', 'Basket'); ?>

<?php $__env->startSection('content'); ?>

    <main class="col_main">
        <container>
            <div class="basket">
                <h1>Ваша корзина</h1>
                <?php if($baskets->count() > 0): ?>
                    <form action="<?php echo e(route('basketAllDelete')); ?>" method="post" class="text-right">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger mb-4 mt-0">
                            Очистить корзину
                        </button>
                    </form>
                    <table class="table table-bordered">
                        <tr>
                            <th>Наименование</th>
                            <th>Цена</th>
                            <th>Кол-во</th>
                            <th>Общая стоимость</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($basket->product->title); ?></td>
                                <td><?php echo e($basket->product->price); ?></td>
                                <td><?php echo e($basket->count); ?></td>
                                <td><?php echo e($basket->price); ?></td>
                                <td>
                                    <div class="quantity_inner">
                                        <button class="bt_minus">
                                            <svg viewBox="0 0 24 24">
                                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                            </svg>
                                        </button>
                                        <input type="text" disabled value="<?php echo e($basket->count); ?>" size="2" class="quantity" data-max-count="20"/>

                                        <form action="<?php echo e(route('basketAdd', $basket->product->id)); ?>" method="POST" style="margin: 0; width: auto">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("POST"); ?>
                                            <button class="bt_plus" type="submit">
                                                <svg viewBox="0 0 24 24">
                                                    <line x1="12" y1="5" x2="12" y2="19"></line>
                                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                                </svg>
                                            </button>
                                        </form>

                                    </div>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('basketDelete', $basket)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="destroy">Удалить</button>
                                    </form>
                                </td>
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="4" class="text-right">Итого</th>
                            <th><?php echo e($baskets->sum('price')); ?></th>
                        </tr>
                    </table>
                    <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success float-right">
                        Оформить заказ
                    </a>
                <?php else: ?>

                    <p>Ваша корзина пуста...</p>

                <?php endif; ?>


            </div>
        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/basket.blade.php ENDPATH**/ ?>