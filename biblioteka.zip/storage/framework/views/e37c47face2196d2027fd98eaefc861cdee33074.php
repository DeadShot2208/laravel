

<?php $__env->startSection('title', 'product'); ?>

<?php $__env->startSection('content'); ?>

    <main class="main-admin">
        <container>
            <div class="wrapp__admin__panel">
                <div class="list__table">
                    <div class="table">
                        <div class="title__table">
                            <p>Товар</p>
                            <a href="<?php echo e(route('add_product')); ?>" class="create">Добавить</a>
                        </div>
                        <table class="table__db">
                            <thead>
                            <th>ID</th>
                            <th>Категория</th>
                            <th>Заголовок</th>
                            <th>краткое описание</th>
                            <th>описание</th>
                            <th>Автор</th>
                            <th>Стоимость</th>
                            <th>image</th>
                            <th>слаг</th>
                            <th>Дата создания</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item_product->id); ?></td>
                                <td><?php echo e($item_product->category_id); ?></td>
                                <td><?php echo e($item_product->title); ?></td>
                                <td style="width: 10%"><?php echo e($item_product->subcontent); ?></td>
                                <td style="width: 25%"><?php echo e($item_product->content); ?></td>
                                <td><?php echo e($item_product->author); ?></td>
                                <td><?php echo e($item_product->price); ?></td>
                                <td><?php if($item_product->image !== ''): ?><img  style="width: 200px;height: 300px" src="<?php echo e(\Illuminate\Support\Facades\Storage::url($item_product->image)); ?>" alt=""><?php endif; ?></td>
                                <td><?php echo e($item_product->slug); ?></td>
                                <td><?php echo e($item_product->created_at); ?></td>
                                <td style="width: 15%">
                                    <a href="<?php echo e(route('edit_product', $item_product->id)); ?>" class="edit">Редактировать</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('product.destroy', $item_product->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="destroy">Удалить</button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <?php echo e($product->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        </container>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/admin/product.blade.php ENDPATH**/ ?>