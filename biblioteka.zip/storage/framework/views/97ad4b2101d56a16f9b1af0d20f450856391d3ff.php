<?php $__env->startSection('title', 'Favorites'); ?>

<?php $__env->startSection('content'); ?>

    <main class="col_main" style="margin-bottom: 300px;">
        <container>
            <div class="zagolovok">
                <h1>Избраное</h1>
            </div>
        <div class="favorites" >
            <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="box_product">
                <img src="<?php echo e(asset('storage/' . $favorite->image)); ?>" alt="">
                <div class="info_product">
                    <h3><?php echo e($favorite->product->title); ?></h3>
                    <div class="opisanie">
                        <p><?php echo e($favorite->product->subcontent); ?></p>
                    </div>
                    <div class="inn">
                        <h4>Автор: <?php echo e($favorite->product->author); ?></h4>
                        <h4>Жанр: <?php echo e($favorite->product->category->title); ?></h4>
                        <h4>Цена: <?php echo e($favorite->product->price); ?></h4>
                    </div>
                    <div class="known">
                        <form action="<?php echo e(route('basketAdd', $favorite->product)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("POST"); ?>
                            <button type="submit" class="button button5">В корзину</button>
                        </form>
                        <form action="<?php echo e(route('favouriteDelete', $favorite->product)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="button button5" >Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <p>Избранное пустое</p>
            <?php endif; ?>

        </div>
        </container>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/favorites.blade.php ENDPATH**/ ?>