<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
    <main class="col_main">
        <container>
            <div class="checkout">
                <h1 class="mb-4">Оформить заказ</h1>

                <form method="POST" action="<?php echo e(route('orderPost')); ?>" id="checkout">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name="name" placeholder="Имя, Фамилия"
                               required maxlength="255" value="">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" name="email" placeholder="Адрес почты"
                               required maxlength="255" value="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="phone" placeholder="Номер телефона"
                               required maxlength="255" value="">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="address" placeholder="Адрес доставки"
                               required maxlength="255" value="">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="comment" placeholder="Комментарий"
                                  maxlength="255" rows="2"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Оформить</button>
                    </div>
                </form>
            </div>
        </container>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/checkout.blade.php ENDPATH**/ ?>