


<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<main class="kontakt_main">
    <container>

        <div class="box-img-kontakt">
            <img src="<?php echo e(asset('img/kontakt.jpg')); ?>" alt="" width="100%" height="700px">
        </div>

        <div class="box-info-kontakt">
            <div class="kontakt-1">
                <h1>Адресс</h1>
                <h3>«Книжник» находится в Златоусте, на ул. Ленина, 2А.</h3>
            </div>
            <div class="kontakt-2">
                <h1>Телефон</h1>
                <h3>+7 (351) 897 29 34</h3>
            </div>
            <div class="kontakt-3">
                <h1>Электроное письмо</h1>
                <h3>Knijnik2022@mail.ru</h3>
            </div>

            <div class="kontakt-4">
                <a href=""><img src="<?php echo e(asset('img/wk.png')); ?>" alt="" ></a>
                <a href=""><img src="<?php echo e(asset('img/insta.png')); ?>" alt=""></a>
                <a href=""><img src="<?php echo e(asset('img/face.png')); ?>" alt=""></a>
                <a href=""><img src="<?php echo e(asset('img/teleg.png')); ?>" alt=""></a>
            </div>
        </div>

    </container>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\biblioteka\resources\views/pages/kontact.blade.php ENDPATH**/ ?>