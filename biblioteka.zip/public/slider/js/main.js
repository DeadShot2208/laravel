new Splide(".splide", {

    type : 'loop',
    drag : 'free',
    focus  : 'center',
    arrows: true,
    pagination: true,
    width: '90%',
    height: '500px',
    fixedWidth : '800px',
    gap: '30px',

    })
    
    .mount();

    